// This file is obsolete. The logic will be handled directly inside the details page or form.
import React from 'react';

const AtribuirProfissionalModal = () => {
  return (
    <div>
      This component is obsolete.
    </div>
  );
};

export default AtribuirProfissionalModal;