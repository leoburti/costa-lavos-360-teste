import React from 'react';
import { Outlet } from 'react-router-dom';

const GeolocalizacaoLayout = () => {
  return (
    <Outlet />
  );
};

export default GeolocalizacaoLayout;