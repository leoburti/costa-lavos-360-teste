import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, X } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const ProtocolDetailReport = React.forwardRef(({ protocol }, ref) => {
    if (!protocol) return null;

    const formattedDate = protocol.data_entrega ? format(new Date(protocol.data_entrega), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR }) : 'N/A';

    return (
        <div ref={ref} className="p-8 bg-white text-black font-sans">
            <header className="mb-8 border-b pb-4">
                <h1 className="text-3xl font-bold">Protocolo de Entrega</h1>
                <p className="text-sm text-gray-600">Gerado em: {format(new Date(), "dd/MM/yyyy HH:mm", { locale: ptBR })}</p>
            </header>

            <main className="space-y-6">
                <section>
                    <h2 className="text-xl font-semibold mb-2 border-b">Detalhes da Entrega</h2>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div><strong>Nota Fiscal:</strong> {protocol.venda_num_docto}</div>
                        <div><strong>Data da Entrega:</strong> {formattedDate}</div>
                        <div><strong>Cliente:</strong> {protocol.cliente_nome}</div>
                        <div><strong>Status:</strong> <Badge variant={protocol.status === 'Concluído' ? 'success' : 'secondary'}>{protocol.status}</Badge></div>
                    </div>
                </section>

                <section>
                    <h2 className="text-xl font-semibold mb-2 border-b">Recebimento</h2>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div><strong>Recebedor:</strong> {protocol.recebedor_nome || 'N/A'}</div>
                        <div><strong>Documento:</strong> {protocol.recebedor_documento || 'N/A'}</div>
                    </div>
                </section>

                <section>
                    <h2 className="text-xl font-semibold mb-2 border-b">Movimentação de Caixas</h2>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div><strong>Caixas Entregues:</strong> {protocol.caixas_entregues}</div>
                        <div><strong>Caixas Recolhidas:</strong> {protocol.caixas_recolhidas}</div>
                    </div>
                </section>

                {protocol.items_status && Object.keys(protocol.items_status).length > 0 && (
                    <section>
                        <h2 className="text-xl font-semibold mb-2 border-b">Checklist de Itens</h2>
                        <ul className="space-y-1 text-sm list-inside">
                            {Object.entries(protocol.items_status).map(([item, checked]) => (
                                <li key={item} className="flex items-center">
                                    {checked ? <Check className="h-4 w-4 text-green-600 mr-2" /> : <X className="h-4 w-4 text-red-500 mr-2" />}
                                    <span>{item}</span>
                                </li>
                            ))}
                        </ul>
                    </section>
                )}

                <section className="space-y-4">
                    <h2 className="text-xl font-semibold mb-2 border-b">Comprovantes</h2>
                    {protocol.assinatura_digital && (
                        <div>
                            <h3 className="font-semibold mb-1">Assinatura do Recebedor:</h3>
                            <div className="border p-2 inline-block rounded-md bg-gray-50">
                                <img src={protocol.assinatura_digital} alt="Assinatura Digital" className="h-24 object-contain" />
                            </div>
                        </div>
                    )}
                    {protocol.foto_comprovante && (
                        <div>
                            <h3 className="font-semibold mb-1">Foto do Canhoto:</h3>
                            <img src={protocol.foto_comprovante} alt="Foto do Canhoto" className="max-w-xs border rounded-md" />
                        </div>
                    )}
                    {protocol.fotos && protocol.fotos.length > 0 && (
                        <div>
                            <h3 className="font-semibold mb-1">Fotos Adicionais:</h3>
                            <div className="grid grid-cols-2 gap-4">
                                {protocol.fotos.map((foto, index) => (
                                    <img key={index} src={foto} alt={`Foto Adicional ${index + 1}`} className="max-w-xs border rounded-md" />
                                ))}
                            </div>
                        </div>
                    )}
                </section>
            </main>

            <footer className="mt-12 pt-4 border-t text-center text-xs text-gray-500">
                <p>Costa Lavos - Sistema de Gestão Comercial</p>
            </footer>
        </div>
    );
});

export default ProtocolDetailReport;