import React from 'react';
import { Loader2 } from 'lucide-react';

const LoadingSpinner = ({ message = "Carregando..." }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[200px] bg-background">
      <Loader2 className="h-12 w-12 animate-spin text-primary" />
      {message && <p className="mt-4 text-muted-foreground">{message}</p>}
    </div>
  );
};

export default LoadingSpinner;