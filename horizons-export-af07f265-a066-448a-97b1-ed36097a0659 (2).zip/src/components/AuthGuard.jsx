import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import LoadingSpinner from '@/components/LoadingSpinner';

const AuthGuard = ({ children, allowedRoles, moduleId, crmRequired = false }) => {
  const { user, userContext, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    console.debug("[AuthGuard] Auth state is loading. Displaying spinner.");
    return <LoadingSpinner message="Verificando autenticação e permissões..." />;
  }

  if (!user) {
    console.debug("[AuthGuard] No user found. Redirecting to /login.");
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (!userContext) {
    console.warn("[AuthGuard] User is authenticated, but userContext is not ready. This might indicate a problem loading user profile. Displaying spinner.");
    return <LoadingSpinner message="Carregando permissões do usuário..." />;
  }

  const hasRequiredRole = allowedRoles ? allowedRoles.includes(userContext.role) : true;
  const canAccessCrmModule = crmRequired ? userContext.canAccessCrm : true;
  const hasModulePermission = moduleId ? userContext.modulePermissions?.[moduleId] : true;
  
  if (!hasRequiredRole || !canAccessCrmModule || !hasModulePermission) {
    console.warn(`[AuthGuard] Access Denied for path: ${location.pathname}. Redirecting to /dashboard.
      - User Role: ${userContext.role} (Required: ${allowedRoles?.join(', ') || 'any'}) -> ${hasRequiredRole ? 'OK' : 'FAIL'}
      - CRM Required: ${crmRequired} | User has CRM Access: ${userContext.canAccessCrm} -> ${canAccessCrmModule ? 'OK' : 'FAIL'}
      - Module Required: ${moduleId || 'none'} | User has module permission: ${hasModulePermission} -> ${hasModulePermission ? 'OK' : 'FAIL'}`);
    return <Navigate to="/dashboard" replace />;
  }

  console.debug(`[AuthGuard] Access Granted for path: ${location.pathname}.`);
  return children;
};

export default AuthGuard;