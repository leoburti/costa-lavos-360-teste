import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import LoadingSpinner from '@/components/LoadingSpinner';
import { handleAuthError, logout, signIn as authSignInService } from '@/services/authService';
import { useToast } from '@/components/ui/use-toast';

export const SupabaseAuthContext = createContext();

export const SupabaseAuthProvider = ({ children }) => {
  const [session, setSession] = useState(null);
  const [user, setUser] = useState(null);
  const [userContext, setUserContext] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchUserContext = useCallback(async (sessionUser) => {
    if (!sessionUser) {
      setUserContext(null);
      return null;
    }

    try {
      const { data, error } = await supabase.rpc('get_user_role', { p_user_id: sessionUser.id });

      if (error) {
        throw new Error(`Error fetching user role: ${error.message}`);
      }

      if (data && data.length > 0) {
        const profile = data[0];
        const contextData = {
          fullName: sessionUser.user_metadata?.full_name || 'Usuário',
          role: profile.role || 'Sem Permissão',
          canAccessCrm: profile.can_access_crm || false,
          modulePermissions: profile.module_permissions || {},
          supervisorName: profile.supervisor_name,
          sellerName: profile.seller_name,
          approvalRoles: profile.approval_roles || {},
        };
        setUserContext(contextData);
        return contextData;
      } else {
        const fallbackContext = {
            fullName: sessionUser.user_metadata?.full_name || 'Usuário',
            role: 'Sem Permissão',
            canAccessCrm: false,
            modulePermissions: {},
            supervisorName: null,
            sellerName: null,
            approvalRoles: {},
        };
        setUserContext(fallbackContext);
        return fallbackContext;
      }
    } catch (error) {
      console.error("[AuthContext] Fatal error in fetchUserContext:", error.message);
      handleAuthError(error);
      setUser(null);
      setUserContext(null);
      return null;
    }
  }, []);

  const forceRoleRefetch = useCallback(async () => {
    if (user) {
      console.log("[AuthContext] Forcing role refetch for user:", user.id);
      setLoading(true);
      await fetchUserContext(user);
      setLoading(false);
    }
  }, [user, fetchUserContext]);

  useEffect(() => {
    setLoading(true);
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if(session?.user){
        fetchUserContext(session.user).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session);
        const sessionUser = session?.user ?? null;
        setUser(sessionUser);
        if (sessionUser) {
          await fetchUserContext(sessionUser);
        } else {
          setUserContext(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, [fetchUserContext]);
  
  const value = {
    session,
    user,
    userContext,
    userRole: userContext?.role,
    loading,
    signOut: logout,
    signIn: async (email, password) => {
        const { error } = await authSignInService(email, password);
        if (error) {
            toast({
                title: 'Erro de Login',
                description: 'E-mail ou senha inválidos. Por favor, tente novamente.',
                variant: 'destructive'
            })
        }
        return { error };
    },
    forceRoleRefetch,
  };

  if (loading && !session) {
    return <div className="flex h-screen w-full items-center justify-center bg-background"><LoadingSpinner message="Verificando autenticação..." /></div>;
  }

  return (
    <SupabaseAuthContext.Provider value={value}>
      {children}
    </SupabaseAuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(SupabaseAuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within a SupabaseAuthProvider');
  }
  return context;
};

// Export alias for compatibility
export const useSupabaseAuth = useAuth;